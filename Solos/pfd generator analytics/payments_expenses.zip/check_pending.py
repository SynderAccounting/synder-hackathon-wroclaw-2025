import pandas as pd

df = pd.read_csv('amazon_orders_table.csv')
pending = df[df['Deposit Date'].isna()]

print(f"Pending orders: {len(pending)}")
print(f"Total Potential Income: ${pending['Potential Income'].sum():.2f}")
print(f"Total Potential Loss: ${pending['Potential Loss'].sum():.2f}")
print(f"Average Loss per order: ${pending['Potential Loss'].mean():.2f}")
print(f"Min Loss: ${pending['Potential Loss'].min():.2f}")
print(f"Max Loss: ${pending['Potential Loss'].max():.2f}")
