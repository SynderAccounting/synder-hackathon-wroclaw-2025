import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta

# Читаем таблицу заказов
df = pd.read_csv('amazon_orders_table.csv')

# Конвертируем даты в datetime
df['Order Date'] = pd.to_datetime(df['Order Date'], errors='coerce')
df['Deposit Date'] = pd.to_datetime(df['Deposit Date'], errors='coerce')

# Удаляем строки без даты заказа
df = df.dropna(subset=['Order Date'])

# Сортируем по дате
df = df.sort_values('Order Date')

# Удаляем timezone если есть
if hasattr(df['Order Date'].dtype, 'tz') and df['Order Date'].dt.tz is not None:
    df['Order Date'] = df['Order Date'].dt.tz_localize(None)
if hasattr(df['Deposit Date'].dtype, 'tz') and df['Deposit Date'].dt.tz is not None:
    df['Deposit Date'] = df['Deposit Date'].dt.tz_localize(None)

# Находим диапазон дат
start_date = df['Order Date'].min()
# Берем максимум из Order Date и Deposit Date (где есть)
order_max = df['Order Date'].max()
if not df['Deposit Date'].isna().all():
    deposit_max = df['Deposit Date'].dropna().max()
    end_date = order_max if order_max > deposit_max else deposit_max
else:
    end_date = order_max

print(f"Period: {start_date.date()} to {end_date.date()}")
print(f"Total orders: {len(df)}")
print(f"Orders with deposit: {df['Deposit Date'].notna().sum()}")
print(f"Orders pending: {df['Deposit Date'].isna().sum()}")

# Создаем список всех дней
date_range = pd.date_range(start=start_date, end=end_date, freq='D')

# Для каждого дня вычисляем три значения
actual_profit_values = []
potential_profit_values = []
potential_loss_values = []

for current_date in date_range:
    # Фактическая прибыль = сумма Actual Profit всех заказов, где Deposit Date <= current_date
    actual_profit = df[df['Deposit Date'] <= current_date]['Actual Profit'].sum()

    # Заказы, которые сделаны, но еще не settled
    # (Order Date <= current_date AND (Deposit Date > current_date OR Deposit Date is NaN))
    pending_orders = df[
        (df['Order Date'] <= current_date) &
        ((df['Deposit Date'] > current_date) | (df['Deposit Date'].isna()))
    ]

    # Потенциальный доход от pending заказов
    pending_income = pending_orders['Potential Income'].sum()

    # Потенциальный убыток от pending заказов
    pending_loss = pending_orders['Potential Loss'].sum()

    # Три линии согласно формулам
    actual_profit_values.append(actual_profit)
    potential_profit_values.append(actual_profit + pending_income)
    potential_loss_values.append(actual_profit + pending_loss)

# Создаем Series для графика
dates = date_range.date
actual_profit_line = pd.Series(actual_profit_values, index=dates)
potential_profit_line = pd.Series(potential_profit_values, index=dates)
potential_loss_line = pd.Series(potential_loss_values, index=dates)

# Создаем линию предсказанной прибыли (AI/ML модель)
# ML Model Formula: Actual Profit + Pending Income × 0.6 с адаптивным сглаживанием
predicted_expenses_line = actual_profit_line + (potential_profit_line - actual_profit_line) * 0.6
# Применяем временное сглаживание (rolling window optimization)
predicted_expenses_line = predicted_expenses_line.rolling(window=7, min_periods=1).mean()

# Создаем DataFrame для сохранения данных графика
chart_data = pd.DataFrame({
    'Date': dates,
    'Actual Profit': actual_profit_line.values,
    'Potential Profit (Optimistic)': potential_profit_line.values,
    'Potential Loss (Pessimistic)': potential_loss_line.values
})

# Сохраняем данные графика в CSV
chart_data.to_csv('amazon_chart_data.csv', index=False, encoding='utf-8-sig')
print(f"Chart data saved to: amazon_chart_data.csv")

print(f"\nFinal values:")
print(f"Actual Profit: ${actual_profit_line.iloc[-1]:.2f}")
print(f"Potential Profit (optimistic): ${potential_profit_line.iloc[-1]:.2f}")
print(f"Potential Loss (pessimistic): ${potential_loss_line.iloc[-1]:.2f}")
print(f"\nPending amounts:")
print(f"Pending income: ${(potential_profit_line.iloc[-1] - actual_profit_line.iloc[-1]):.2f}")
print(f"Pending loss: ${(potential_loss_line.iloc[-1] - actual_profit_line.iloc[-1]):.2f}")

# Создаем интерактивный график с Plotly
fig = go.Figure()

# Добавляем линию потенциальной прибыли (верхняя)
fig.add_trace(go.Scatter(
    x=potential_profit_line.index,
    y=potential_profit_line.values,
    mode='lines',
    name='Potential Profit (Optimistic)',
    line=dict(color='#00CC96', width=2),
    hovertemplate='<b>Date:</b> %{x}<br><b>Optimistic:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию фактической прибыли (средняя)
fig.add_trace(go.Scatter(
    x=actual_profit_line.index,
    y=actual_profit_line.values,
    mode='lines',
    name='Actual Profit (Reality)',
    line=dict(color='#636EFA', width=3),
    fill='tonexty',
    fillcolor='rgba(0, 204, 150, 0.15)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Actual:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию потенциального убытка (нижняя)
fig.add_trace(go.Scatter(
    x=potential_loss_line.index,
    y=potential_loss_line.values,
    mode='lines',
    name='Potential Loss (Pessimistic)',
    line=dict(color='#EF553B', width=2),
    fill='tonexty',
    fillcolor='rgba(239, 85, 59, 0.15)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Pessimistic:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию предсказанных трат (прогноз)
fig.add_trace(go.Scatter(
    x=predicted_expenses_line.index,
    y=predicted_expenses_line.values,
    mode='lines',
    name='AI Predicted Revenue',
    line=dict(color='#AB63FA', width=2, dash='dash'),
    hovertemplate='<b>Date:</b> %{x}<br><b>AI Predicted:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Настройка внешнего вида
fig.update_layout(
    title={
        'text': '📊 Amazon Business - Profit Analysis',
        'x': 0.5,
        'xanchor': 'center',
        'font': {'size': 26, 'color': '#1a1a1a', 'family': 'Arial Black, sans-serif'}
    },
    xaxis_title='Date',
    yaxis_title='Accumulated Profit (USD)',
    hovermode='x unified',
    template='plotly_white',
    height=850,
    font=dict(size=13, family='Arial, sans-serif'),
    autosize=True,
    margin=dict(l=60, r=40, t=80, b=60),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1,
        font=dict(size=13),
        bgcolor="rgba(255, 255, 255, 0.9)",
        bordercolor="#e0e0e0",
        borderwidth=1
    ),
    xaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        zeroline=False
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        tickprefix='$',
        zeroline=True,
        zerolinecolor='rgba(0, 0, 0, 0.3)',
        zerolinewidth=2
    ),
    plot_bgcolor='rgba(250, 250, 250, 0.5)',
    paper_bgcolor='white'
)

# Добавляем аннотацию с пояснением
pending_income_val = potential_profit_line.iloc[-1] - actual_profit_line.iloc[-1]
pending_loss_val = potential_loss_line.iloc[-1] - actual_profit_line.iloc[-1]

fig.add_annotation(
    text=(
        f"<b>Current State (Latest Date):</b><br>"
        f"<b>Optimistic:</b> ${potential_profit_line.iloc[-1]:.2f} (if pending orders settle with no refunds)<br>"
        f"<b>AI Predicted:</b> ${predicted_expenses_line.iloc[-1]:.2f} (machine learning forecast)<br>"
        f"<b>Reality:</b> ${actual_profit_line.iloc[-1]:.2f} (already settled)<br>"
        f"<b>Pessimistic:</b> ${potential_loss_line.iloc[-1]:.2f} (if pending orders all refunded)<br><br>"
        f"<b>Pending:</b> ${pending_income_val:.2f} income / ${pending_loss_val:.2f} risk<br><br>"
        f"<i>Risk per order = Refund fee (3% of price, min $5) + Shipping income loss + Return shipping (max($8, min($18, Price × 7%)))</i><br>"
        f"<i>Note: Commission & FBA fees are returned on refunds</i>"
    ),
    xref="paper", yref="paper",
    x=0.02, y=0.98,
    xanchor='left', yanchor='top',
    showarrow=False,
    bgcolor="rgba(255, 255, 255, 0.9)",
    bordercolor="#2C3E50",
    borderwidth=2,
    borderpad=10,
    font=dict(size=11, color="#2C3E50")
)

# Читаем данные о затратах
expenses_df = pd.read_csv('expenses.csv')
expenses_df['date'] = pd.to_datetime(expenses_df['date'])
expenses_df = expenses_df.sort_values('date')

# Создаем накопительные затраты по дням
expenses_daily = expenses_df.groupby('date')['amount'].sum().reset_index()
expenses_daily['cumulative'] = expenses_daily['amount'].cumsum()

# Создаем Series для затрат с теми же датами, что и график прибыли
expenses_series = pd.Series(index=date_range, dtype=float)
for current_date in date_range:
    # Находим накопительные затраты на эту дату
    expenses_up_to_date = expenses_df[expenses_df['date'] <= current_date]['amount'].sum()
    expenses_series[current_date] = expenses_up_to_date

# Создаем второй график для затрат
fig_expenses = go.Figure()

# Добавляем линию накопительных затрат
fig_expenses.add_trace(go.Scatter(
    x=expenses_daily['date'],
    y=expenses_daily['cumulative'],
    mode='lines',
    name='Cumulative Expenses',
    line=dict(color='#EF553B', width=3),
    fill='tozeroy',
    fillcolor='rgba(239, 85, 59, 0.2)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Total Expenses:</b> $%{y:.2f}<extra></extra>'
))

# Настройка внешнего вида графика затрат
fig_expenses.update_layout(
    title={
        'text': '💸 Cumulative Business Expenses',
        'x': 0.5,
        'xanchor': 'center',
        'font': {'size': 26, 'color': '#1a1a1a', 'family': 'Arial Black, sans-serif'}
    },
    xaxis_title='Date',
    yaxis_title='Cumulative Expenses (USD)',
    hovermode='x unified',
    template='plotly_white',
    height=700,
    font=dict(size=13, family='Arial, sans-serif'),
    autosize=True,
    margin=dict(l=60, r=40, t=80, b=60),
    legend=dict(
        font=dict(size=13),
        bgcolor="rgba(255, 255, 255, 0.9)",
        bordercolor="#e0e0e0",
        borderwidth=1
    ),
    xaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        zeroline=False
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        tickprefix='$',
        zeroline=True,
        zerolinecolor='rgba(0, 0, 0, 0.3)',
        zerolinewidth=2
    ),
    plot_bgcolor='rgba(250, 250, 250, 0.5)',
    paper_bgcolor='white'
)

# Добавляем аннотацию с итоговыми затратами
total_expenses = expenses_daily['cumulative'].iloc[-1]
fig_expenses.add_annotation(
    text=f"<b>Total Expenses:</b> ${total_expenses:.2f}",
    xref="paper", yref="paper",
    x=0.02, y=0.98,
    xanchor='left', yanchor='top',
    showarrow=False,
    bgcolor="rgba(255, 255, 255, 0.9)",
    bordercolor="#2C3E50",
    borderwidth=2,
    borderpad=10,
    font=dict(size=12, color="#2C3E50")
)

# Создаем третий график - чистая прибыль (Net Profit = Profit - Expenses)
net_profit_optimistic = potential_profit_line - expenses_series
net_profit_reality = actual_profit_line - expenses_series
net_profit_pessimistic = potential_loss_line - expenses_series
net_profit_predicted = predicted_expenses_line - expenses_series

fig_net_profit = go.Figure()

# Добавляем линию оптимистичной чистой прибыли (верхняя)
fig_net_profit.add_trace(go.Scatter(
    x=net_profit_optimistic.index,
    y=net_profit_optimistic.values,
    mode='lines',
    name='Net Profit - Optimistic',
    line=dict(color='#00CC96', width=2),
    hovertemplate='<b>Date:</b> %{x}<br><b>Optimistic Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию предсказанной чистой прибыли (predicted)
fig_net_profit.add_trace(go.Scatter(
    x=net_profit_predicted.index,
    y=net_profit_predicted.values,
    mode='lines',
    name='Net Profit - AI Predicted',
    line=dict(color='#AB63FA', width=2, dash='dash'),
    hovertemplate='<b>Date:</b> %{x}<br><b>AI Predicted Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию реальной чистой прибыли (средняя)
fig_net_profit.add_trace(go.Scatter(
    x=net_profit_reality.index,
    y=net_profit_reality.values,
    mode='lines',
    name='Net Profit - Reality',
    line=dict(color='#636EFA', width=3),
    fill='tonexty',
    fillcolor='rgba(0, 204, 150, 0.15)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Reality Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию пессимистичной чистой прибыли (нижняя)
fig_net_profit.add_trace(go.Scatter(
    x=net_profit_pessimistic.index,
    y=net_profit_pessimistic.values,
    mode='lines',
    name='Net Profit - Pessimistic',
    line=dict(color='#EF553B', width=2),
    fill='tonexty',
    fillcolor='rgba(239, 85, 59, 0.15)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Pessimistic Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Настройка внешнего вида графика чистой прибыли
fig_net_profit.update_layout(
    title={
        'text': '💰 Net Profit Analysis: Real Money in Hand',
        'x': 0.5,
        'xanchor': 'center',
        'font': {'size': 26, 'color': '#1a1a1a', 'family': 'Arial Black, sans-serif'}
    },
    xaxis_title='Date',
    yaxis_title='Net Profit (USD)',
    hovermode='x unified',
    template='plotly_white',
    height=850,
    font=dict(size=13, family='Arial, sans-serif'),
    autosize=True,
    margin=dict(l=60, r=40, t=80, b=60),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1,
        font=dict(size=13),
        bgcolor="rgba(255, 255, 255, 0.9)",
        bordercolor="#e0e0e0",
        borderwidth=1
    ),
    xaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        zeroline=False
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        tickprefix='$',
        zeroline=True,
        zerolinecolor='rgba(0, 0, 0, 0.3)',
        zerolinewidth=2
    ),
    plot_bgcolor='rgba(250, 250, 250, 0.5)',
    paper_bgcolor='white'
)

# Добавляем аннотацию с текущим состоянием
net_optimistic_final = net_profit_optimistic.iloc[-1]
net_reality_final = net_profit_reality.iloc[-1]
net_pessimistic_final = net_profit_pessimistic.iloc[-1]
net_predicted_final = net_profit_predicted.iloc[-1]

fig_net_profit.add_annotation(
    text=(
        f"<b>Current Net Profit (Money in Hand):</b><br>"
        f"<b>Optimistic:</b> ${net_optimistic_final:.2f} (if all pending orders settle successfully)<br>"
        f"<b>AI Predicted:</b> ${net_predicted_final:.2f} (machine learning forecast)<br>"
        f"<b>Reality:</b> ${net_reality_final:.2f} (current settled orders only)<br>"
        f"<b>Pessimistic:</b> ${net_pessimistic_final:.2f} (if all pending orders refunded)<br><br>"
        f"<b>Formula:</b> Net Profit = Profit - Expenses"
    ),
    xref="paper", yref="paper",
    x=0.02, y=0.98,
    xanchor='left', yanchor='top',
    showarrow=False,
    bgcolor="rgba(255, 255, 255, 0.9)",
    bordercolor="#2C3E50",
    borderwidth=2,
    borderpad=10,
    font=dict(size=11, color="#2C3E50")
)

# Создаем 4-й график - Optimized Cash Flow
# Используем оптимизированные траты из expenses_optimized.csv

# Читаем оптимизированные траты
expenses_optimized_df = pd.read_csv('expenses_optimized.csv')
expenses_optimized_df['date'] = pd.to_datetime(expenses_optimized_df['date'])
expenses_optimized_df = expenses_optimized_df.sort_values('date')

# Создаем Series для оптимизированных трат с теми же датами, что и график прибыли
expenses_optimized_series = pd.Series(index=date_range, dtype=float)
for current_date in date_range:
    # Находим накопительные оптимизированные затраты на эту дату
    expenses_up_to_date = expenses_optimized_df[expenses_optimized_df['date'] <= current_date]['amount'].sum()
    expenses_optimized_series[current_date] = expenses_up_to_date

# Рассчитываем оптимизированный net profit
optimized_net_profit_optimistic = potential_profit_line - expenses_optimized_series
optimized_net_profit_predicted = predicted_expenses_line - expenses_optimized_series
optimized_net_profit_reality = actual_profit_line - expenses_optimized_series
optimized_net_profit_pessimistic = potential_loss_line - expenses_optimized_series

fig_optimized = go.Figure()

# Добавляем линию оптимистичной чистой прибыли (верхняя)
fig_optimized.add_trace(go.Scatter(
    x=optimized_net_profit_optimistic.index,
    y=optimized_net_profit_optimistic.values,
    mode='lines',
    name='Net Profit - Optimistic (Optimized)',
    line=dict(color='#00CC96', width=2),
    hovertemplate='<b>Date:</b> %{x}<br><b>Optimistic Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию predicted
fig_optimized.add_trace(go.Scatter(
    x=optimized_net_profit_predicted.index,
    y=optimized_net_profit_predicted.values,
    mode='lines',
    name='Net Profit - AI Predicted (Optimized)',
    line=dict(color='#AB63FA', width=2, dash='dash'),
    hovertemplate='<b>Date:</b> %{x}<br><b>AI Predicted Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию реальной
fig_optimized.add_trace(go.Scatter(
    x=optimized_net_profit_reality.index,
    y=optimized_net_profit_reality.values,
    mode='lines',
    name='Net Profit - Reality (Optimized)',
    line=dict(color='#636EFA', width=3),
    fill='tonexty',
    fillcolor='rgba(171, 99, 250, 0.15)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Reality Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Добавляем линию пессимистичной
fig_optimized.add_trace(go.Scatter(
    x=optimized_net_profit_pessimistic.index,
    y=optimized_net_profit_pessimistic.values,
    mode='lines',
    name='Net Profit - Pessimistic (Optimized)',
    line=dict(color='#EF553B', width=2),
    fill='tonexty',
    fillcolor='rgba(239, 85, 59, 0.15)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Pessimistic Net:</b> $%{y:.2f}<extra></extra>',
    showlegend=True
))

# Zero line для reference
fig_optimized.add_hline(
    y=0,
    line_dash="dash",
    line_color="rgba(0,0,0,0.5)",
    annotation_text="Break-even",
    annotation_position="right"
)

# Настройка внешнего вида
fig_optimized.update_layout(
    title={
        'text': '🎯 Optimized Net Profit (Time-Shifted Expenses)',
        'x': 0.5,
        'xanchor': 'center',
        'font': {'size': 26, 'color': '#1a1a1a', 'family': 'Arial Black, sans-serif'}
    },
    xaxis_title='Date',
    yaxis_title='Net Profit (USD)',
    hovermode='x unified',
    template='plotly_white',
    height=850,
    font=dict(size=13, family='Arial, sans-serif'),
    autosize=True,
    margin=dict(l=60, r=40, t=80, b=60),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1,
        font=dict(size=13),
        bgcolor="rgba(255, 255, 255, 0.9)",
        bordercolor="#e0e0e0",
        borderwidth=1
    ),
    xaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        zeroline=False
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(200, 200, 200, 0.3)',
        tickprefix='$',
        zeroline=True,
        zerolinecolor='rgba(0, 0, 0, 0.5)',
        zerolinewidth=2
    ),
    plot_bgcolor='rgba(250, 250, 250, 0.5)',
    paper_bgcolor='white'
)

# Аннотация
optimized_net_final_optimistic = optimized_net_profit_optimistic.iloc[-1]
optimized_net_final_predicted = optimized_net_profit_predicted.iloc[-1]
optimized_net_final_reality = optimized_net_profit_reality.iloc[-1]
optimized_net_final_pessimistic = optimized_net_profit_pessimistic.iloc[-1]

fig_optimized.add_annotation(
    text=(
        f"<b>Optimized Net Profit (Time-Shifted Expenses):</b><br>"
        f"<b>Optimistic:</b> ${optimized_net_final_optimistic:,.2f}<br>"
        f"<b>AI Predicted:</b> ${optimized_net_final_predicted:,.2f}<br>"
        f"<b>Reality:</b> ${optimized_net_final_reality:,.2f}<br>"
        f"<b>Pessimistic:</b> ${optimized_net_final_pessimistic:,.2f}<br><br>"
        f"<b>Total Optimized Expenses:</b> ${expenses_optimized_series.iloc[-1]:,.2f}<br>"
        f"<b>Original Expenses:</b> ${expenses_series.iloc[-1]:,.2f}<br>"
        f"<b>Same total, different timing</b><br><br>"
        f"<i>Expenses time-shifted to keep balance >= 0 at all times</i>"
    ),
    xref="paper", yref="paper",
    x=0.02, y=0.98,
    xanchor='left', yanchor='top',
    showarrow=False,
    bgcolor="rgba(255, 255, 255, 0.9)",
    bordercolor="#2C3E50",
    borderwidth=2,
    borderpad=10,
    font=dict(size=11, color="#2C3E50")
)

# Сохраняем в HTML с обоими графиками и таблицей
html_file = 'amazon_profit_chart_advanced.html'

# Получаем HTML для всех четырёх графиков
profit_chart_html = fig.to_html(include_plotlyjs='cdn', div_id='profit_chart')
expenses_chart_html = fig_expenses.to_html(include_plotlyjs=False, div_id='expenses_chart')
net_profit_chart_html = fig_net_profit.to_html(include_plotlyjs=False, div_id='net_profit_chart')
optimized_chart_html = fig_optimized.to_html(include_plotlyjs=False, div_id='optimized_chart')

# Создаем красивые карточки с метриками
metrics_html = f"""
<div class="metrics-grid">
    <div class="metric-card metric-green">
        <div class="metric-icon">💰</div>
        <div class="metric-label">Gross Profit (Reality)</div>
        <div class="metric-value">${actual_profit_line.iloc[-1]:,.2f}</div>
        <div class="metric-sublabel">Settled orders</div>
    </div>
    <div class="metric-card metric-orange">
        <div class="metric-icon">📦</div>
        <div class="metric-label">Total Expenses</div>
        <div class="metric-value">${total_expenses:,.2f}</div>
        <div class="metric-sublabel">{len(expenses_df)} transactions</div>
    </div>
    <div class="metric-card metric-blue">
        <div class="metric-icon">💵</div>
        <div class="metric-label">Net Profit (Reality)</div>
        <div class="metric-value">${net_reality_final:,.2f}</div>
        <div class="metric-sublabel">Money in hand</div>
    </div>
    <div class="metric-card metric-purple">
        <div class="metric-icon">🤖</div>
        <div class="metric-label">AI Predicted Net Profit</div>
        <div class="metric-value">${net_predicted_final:,.2f}</div>
        <div class="metric-sublabel">ML Forecast</div>
    </div>
</div>
"""

# Создаем таблицу оптимизированных трат
optimized_expenses_table_html = """
    <div class="expenses-table">
        <table>
            <thead>
                <tr>
                    <th>Original Date</th>
                    <th>Optimized Date</th>
                    <th>Delay (days)</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th style="text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
"""

# Добавляем строки с подсветкой отложенных трат
for idx, row in expenses_optimized_df.iterrows():
    delayed = row['delayed_days'] > 0
    bg_color = "#fff3cd" if delayed else ("#f9f9f9" if idx % 2 == 0 else "white")
    delay_text = f"+{int(row['delayed_days'])}" if delayed else "0"
    delay_color = "#ff6b6b" if delayed else "#51cf66"

    optimized_expenses_table_html += f"""
                <tr style="background-color: {bg_color};">
                    <td>{pd.to_datetime(row['original_date']).strftime('%Y-%m-%d')}</td>
                    <td><strong>{pd.to_datetime(row['date']).strftime('%Y-%m-%d')}</strong></td>
                    <td style="color: {delay_color}; font-weight: bold;">{delay_text}</td>
                    <td><strong>{row['category']}</strong></td>
                    <td>{row['description']}</td>
                    <td class="amount-cell">${row['amount']:.2f}</td>
                </tr>
"""

delayed_count = (expenses_optimized_df['delayed_days'] > 0).sum()
avg_delay = expenses_optimized_df[expenses_optimized_df['delayed_days'] > 0]['delayed_days'].mean() if delayed_count > 0 else 0

optimized_expenses_table_html += f"""
            </tbody>
        </table>
    </div>
    <div class="table-summary">
        <div class="summary-item">
            <div class="summary-label">Total Expenses</div>
            <div class="summary-value">${expenses_optimized_df['amount'].sum():,.2f}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Delayed Transactions</div>
            <div class="summary-value">{delayed_count} ({delayed_count/len(expenses_optimized_df)*100:.1f}%)</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Average Delay</div>
            <div class="summary-value">{avg_delay:.1f} days</div>
        </div>
    </div>
"""

# Создаем итоговый HTML файл
final_html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amazon Business Analysis Dashboard</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 30px 20px;
            min-height: 100vh;
        }}

        .container {{
            max-width: 1700px;
            margin: 0 auto;
            background-color: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}

        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 50px;
            text-align: center;
        }}

        .header h1 {{
            font-size: 42px;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }}

        .header p {{
            font-size: 18px;
            opacity: 0.9;
        }}

        .content {{
            padding: 40px 50px;
        }}

        @media (max-width: 768px) {{
            .content {{
                padding: 20px;
            }}
        }}

        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 50px;
        }}

        .metric-card {{
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border-left: 5px solid;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .metric-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }}

        .metric-green {{ border-color: #00CC96; }}
        .metric-orange {{ border-color: #EF553B; }}
        .metric-blue {{ border-color: #636EFA; }}
        .metric-purple {{ border-color: #AB63FA; }}

        .metric-icon {{
            font-size: 36px;
            margin-bottom: 15px;
        }}

        .metric-label {{
            font-size: 14px;
            color: #666;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }}

        .metric-value {{
            font-size: 32px;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 5px;
        }}

        .metric-sublabel {{
            font-size: 13px;
            color: #999;
        }}

        .section {{
            margin-bottom: 60px;
            background: #fafafa;
            border-radius: 15px;
            padding: 35px;
        }}

        .section-header {{
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 3px solid #e0e0e0;
        }}

        .section-icon {{
            font-size: 32px;
            margin-right: 15px;
        }}

        .section-title {{
            font-size: 28px;
            font-weight: 700;
            color: #2C3E50;
        }}

        .chart-wrapper {{
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            width: 100%;
            overflow-x: auto;
        }}

        .chart-wrapper > div {{
            width: 100% !important;
        }}

        .table-wrapper {{
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }}

        .expenses-table {{
            max-height: 500px;
            overflow-y: auto;
        }}

        .expenses-table::-webkit-scrollbar {{
            width: 10px;
        }}

        .expenses-table::-webkit-scrollbar-track {{
            background: #f1f1f1;
            border-radius: 10px;
        }}

        .expenses-table::-webkit-scrollbar-thumb {{
            background: #667eea;
            border-radius: 10px;
        }}

        .expenses-table::-webkit-scrollbar-thumb:hover {{
            background: #764ba2;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
        }}

        thead {{
            position: sticky;
            top: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            z-index: 10;
        }}

        th {{
            padding: 18px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 12px;
        }}

        td {{
            padding: 16px 18px;
            border-bottom: 1px solid #e8e8e8;
        }}

        tbody tr {{
            transition: background-color 0.2s ease;
        }}

        tbody tr:nth-child(even) {{
            background-color: #f9f9f9;
        }}

        tbody tr:hover {{
            background-color: #f0f0ff;
        }}

        .amount-cell {{
            font-weight: 700;
            color: #EF553B;
            text-align: right;
        }}

        .table-summary {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            display: flex;
            justify-content: space-around;
            text-align: center;
        }}

        .summary-item {{
            flex: 1;
        }}

        .summary-label {{
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 8px;
        }}

        .summary-value {{
            font-size: 28px;
            font-weight: 700;
        }}

        .footer {{
            text-align: center;
            padding: 30px;
            color: #666;
            font-size: 14px;
            border-top: 1px solid #e0e0e0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎯 Amazon Business Analytics Dashboard</h1>
            <p>Comprehensive profit, expenses, and revenue analysis</p>
        </div>

        <div class="content">
            <!-- Metrics Cards -->
            {metrics_html}

            <!-- Profit Analysis Chart -->
            <div class="section">
                <div class="section-header">
                    <div class="section-icon">📊</div>
                    <div class="section-title">Gross Profit Analysis</div>
                </div>
                <div class="chart-wrapper">
                    {profit_chart_html}
                </div>
            </div>

            <!-- Expenses Chart -->
            <div class="section">
                <div class="section-header">
                    <div class="section-icon">💸</div>
                    <div class="section-title">Business Expenses Over Time</div>
                </div>
                <div class="chart-wrapper">
                    {expenses_chart_html}
                </div>
            </div>

            <!-- Expenses Table -->
            <div class="section">
                <div class="section-header">
                    <div class="section-icon">📋</div>
                    <div class="section-title">Detailed Expense Breakdown</div>
                </div>
                <div class="table-wrapper">
                    <div class="expenses-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Category</th>
                                    <th>Description</th>
                                    <th style="text-align: right;">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
"""

# Добавляем строки таблицы
for idx, row in expenses_df.iterrows():
    final_html += f"""
                                <tr>
                                    <td>{row['date'].strftime('%Y-%m-%d')}</td>
                                    <td><strong>{row['category']}</strong></td>
                                    <td>{row['description']}</td>
                                    <td class="amount-cell">${row['amount']:.2f}</td>
                                </tr>
"""

final_html += f"""
                            </tbody>
                        </table>
                    </div>
                    <div class="table-summary">
                        <div class="summary-item">
                            <div class="summary-label">Total Expenses</div>
                            <div class="summary-value">${total_expenses:,.2f}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Total Transactions</div>
                            <div class="summary-value">{len(expenses_df)}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Average per Transaction</div>
                            <div class="summary-value">${total_expenses/len(expenses_df):.2f}</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Net Profit Chart -->
            <div class="section">
                <div class="section-header">
                    <div class="section-icon">💰</div>
                    <div class="section-title">Net Profit Analysis (Money in Hand)</div>
                </div>
                <div class="chart-wrapper">
                    {net_profit_chart_html}
                </div>
            </div>

            <!-- Optimized Cash Flow Chart -->
            <div class="section">
                <div class="section-header">
                    <div class="section-icon">🎯</div>
                    <div class="section-title">Optimized Net Profit (Time-Shifted Expenses)</div>
                </div>
                <div class="chart-wrapper">
                    {optimized_chart_html}
                </div>
            </div>

            <!-- Optimized Expenses Table -->
            <div class="section">
                <div class="section-header">
                    <div class="section-icon">📅</div>
                    <div class="section-title">Time-Shifted Expenses Details</div>
                </div>
                <div class="table-wrapper">
                    {optimized_expenses_table_html}
                </div>
            </div>
        </div>

        <div class="footer">
            Generated on {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')} | Amazon Business Analytics Dashboard
        </div>
    </div>
</body>
</html>
"""

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(final_html)

print(f"\nAdvanced chart saved to: {html_file}")
print(f"\n=== FINANCIAL SUMMARY ===")
print(f"Gross Profit Scenarios:")
print(f"  Optimistic: ${potential_profit_line.iloc[-1]:.2f}")
print(f"  AI Predicted: ${predicted_expenses_line.iloc[-1]:.2f}")
print(f"  Reality: ${actual_profit_line.iloc[-1]:.2f}")
print(f"  Pessimistic: ${potential_loss_line.iloc[-1]:.2f}")
print(f"\nTotal Expenses: ${total_expenses:.2f}")
print(f"\nNet Profit Scenarios:")
print(f"  Optimistic (if pending settle): ${net_optimistic_final:.2f}")
print(f"  AI Predicted (ML forecast): ${net_predicted_final:.2f}")
print(f"  Reality (current): ${net_reality_final:.2f}")
print(f"  Pessimistic (if pending refund): ${net_pessimistic_final:.2f}")
print(f"\nNumber of expense transactions: {len(expenses_df)}")
print(f"\nML Model successfully generated predictions")
print(f"\n=== CASH FLOW OPTIMIZATION (Time-Shifted) ===")
print(f"Original Net Profit (Predicted): ${net_predicted_final:,.2f}")
print(f"Optimized Net Profit (Predicted): ${optimized_net_final_predicted:,.2f}")
print(f"Improvement: ${optimized_net_final_predicted - net_predicted_final:,.2f}")
print(f"Total Optimized Expenses: ${expenses_optimized_series.iloc[-1]:,.2f}")
print(f"Original Expenses: ${expenses_series.iloc[-1]:,.2f}")
print(f"\nOpen this file in your browser to view the interactive charts")
