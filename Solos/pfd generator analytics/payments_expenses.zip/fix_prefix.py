import pandas as pd

# Читаем CSV файл
df = pd.read_csv('amazon_orders_table.csv', encoding='utf-8-sig')

# Убираем дублированный префикс и оставляем только один
df['Settlement ID'] = df['Settlement ID'].astype(str).str.replace('amazon_amazon_', 'amazon_', regex=False)

# Сохраняем обратно
df.to_csv('amazon_orders_table.csv', index=False, encoding='utf-8-sig')

print("Prefix fixed successfully!")
print(f"Processed rows: {len(df)}")
print(f"\nFirst 5 rows:")
print(df[['Settlement ID', 'Order ID']].head())
