import pandas as pd
from datetime import datetime, timedelta

def process_amazon_settlement(input_file, output_file='amazon_processed.csv'):
    """
    Обрабатывает Amazon Settlement Report и создает упрощенную версию с 4 колонками:
    - Transaction ID (Order ID)
    - Дата оплаты заказа
    - Чистый доход продавца
    - Прогнозируемая дата выплаты
    """

    # Читаем CSV файл
    df = pd.read_csv(input_file)

    # Фильтруем только транзакции типа Order и Refund (основные транзакции продаж)
    transaction_df = df[df['transaction-type'].isin(['Order', 'Refund'])].copy()

    # Группируем по order-id и вычисляем чистый доход для каждого заказа
    # Чистый доход = сумма всех amount (включая отрицательные комиссии)
    grouped = transaction_df.groupby('order-id').agg({
        'amount': 'sum',  # Суммируем все amount для получения чистого дохода
        'posted-date': 'first',  # Берем первую дату оплаты
        'settlement-end-date': 'first'  # Берем дату окончания settlement
    }).reset_index()

    # Переименовываем колонки
    grouped.columns = ['transaction_id', 'net_profit', 'payment_date', 'settlement_end_date']

    # Вычисляем прогнозируемую дату выплаты: settlement_end_date + 2 дня
    def calculate_payout_date(settlement_end):
        if pd.isna(settlement_end) or settlement_end == '':
            return None
        try:
            # Парсим дату (формат: 2025-05-01 06:01:40 UTC)
            date_obj = datetime.strptime(settlement_end, '%Y-%m-%d %H:%M:%S %Z')
            # Добавляем 2 дня
            payout_date = date_obj + timedelta(days=2)
            return payout_date.strftime('%Y-%m-%d')
        except:
            return None

    grouped['predicted_payout_date'] = grouped['settlement_end_date'].apply(calculate_payout_date)

    # Форматируем дату оплаты (убираем время, оставляем только дату)
    grouped['payment_date'] = pd.to_datetime(grouped['payment_date']).dt.strftime('%Y-%m-%d')

    # Округляем чистый доход до 2 знаков после запятой
    grouped['net_profit'] = grouped['net_profit'].round(2)

    # Выбираем финальные 4 колонки в нужном порядке
    result = grouped[['transaction_id', 'payment_date', 'net_profit', 'predicted_payout_date']]

    # Сортируем по дате оплаты
    result = result.sort_values('payment_date')

    # Сохраняем результат
    result.to_csv(output_file, index=False)

    print(f"Обработка завершена!")
    print(f"Обработано {len(result)} заказов")
    print(f"\nПримеры данных:")
    print(result.head(10))
    print(f"\nСтатистика:")
    print(f"Общий чистый доход: ${result['net_profit'].sum():.2f}")
    print(f"Средний чистый доход на заказ: ${result['net_profit'].mean():.2f}")
    print(f"Диапазон дат: {result['payment_date'].min()} - {result['payment_date'].max()}")

    return result

if __name__ == "__main__":
    # Обрабатываем файл
    result = process_amazon_settlement('amazon.csv', 'amazon_processed.csv')
