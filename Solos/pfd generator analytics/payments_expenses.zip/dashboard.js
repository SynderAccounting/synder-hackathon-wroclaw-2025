// State management
const state = {
    amazonFile: null,
    shopifyFile: null,
    expensesFile: null,
    chartsData: null
};

// Initialize drag and drop functionality
function initDragAndDrop() {
    const amazonDropzone = document.getElementById('amazonDropzone');
    const shopifyDropzone = document.getElementById('shopifyDropzone');
    const expensesDropzone = document.getElementById('expensesDropzone');
    const amazonFileInput = document.getElementById('amazonFile');
    const shopifyFileInput = document.getElementById('shopifyFile');
    const expensesFileInput = document.getElementById('expensesFile');

    // Amazon dropzone
    setupDropzone(amazonDropzone, amazonFileInput, 'amazon');

    // Shopify dropzone
    setupDropzone(shopifyDropzone, shopifyFileInput, 'shopify');

    // Expenses dropzone
    setupDropzone(expensesDropzone, expensesFileInput, 'expenses');

    // Upload button
    document.getElementById('uploadButton').addEventListener('click', uploadAndProcess);
}

function setupDropzone(dropzone, fileInput, type) {
    // Click to browse
    dropzone.addEventListener('click', () => fileInput.click());

    // File input change
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0], type);
        }
    });

    // Drag and drop events
    dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
    });

    dropzone.addEventListener('dragleave', () => {
        dropzone.classList.remove('dragover');
    });

    dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');

        if (e.dataTransfer.files.length > 0) {
            handleFileSelect(e.dataTransfer.files[0], type);
        }
    });
}

function handleFileSelect(file, type) {
    // Validate file type
    if (!file.name.endsWith('.csv')) {
        showError('Please upload a CSV file');
        return;
    }

    // Store file
    if (type === 'amazon') {
        state.amazonFile = file;
        document.getElementById('amazonFileName').textContent = `✓ ${file.name}`;
        document.getElementById('amazonDropzone').classList.add('uploaded');
    } else if (type === 'shopify') {
        state.shopifyFile = file;
        document.getElementById('shopifyFileName').textContent = `✓ ${file.name}`;
        document.getElementById('shopifyDropzone').classList.add('uploaded');
    } else if (type === 'expenses') {
        state.expensesFile = file;
        document.getElementById('expensesFileName').textContent = `✓ ${file.name}`;
        document.getElementById('expensesDropzone').classList.add('uploaded');
    }

    // Enable upload button if all files are selected
    updateUploadButton();
}

function updateUploadButton() {
    const uploadButton = document.getElementById('uploadButton');
    // Требуется хотя бы один источник платежей (Amazon или Shopify) и обязательно Expenses
    const hasPaymentSource = state.amazonFile || state.shopifyFile;
    uploadButton.disabled = !(hasPaymentSource && state.expensesFile);
}

async function uploadAndProcess() {
    const loading = document.getElementById('loading');
    const uploadButton = document.getElementById('uploadButton');
    const errorMessage = document.getElementById('errorMessage');

    // Hide error
    errorMessage.classList.remove('show');

    // Show loading
    loading.classList.add('show');
    uploadButton.disabled = true;

    try {
        // Create form data
        const formData = new FormData();
        if (state.amazonFile) {
            formData.append('amazon', state.amazonFile);
        }
        if (state.shopifyFile) {
            formData.append('shopify', state.shopifyFile);
        }
        formData.append('expenses', state.expensesFile);

        // Upload to server
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (!result.success) {
            throw new Error(result.error || 'Upload failed');
        }

        // Store data
        state.chartsData = result.data;

        // Render charts
        renderDashboard(result.data);

        // Hide loading
        loading.classList.remove('show');

        // Show charts section
        document.getElementById('chartsSection').classList.add('show');

        // Scroll to charts
        setTimeout(() => {
            document.getElementById('chartsSection').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }, 300);

    } catch (error) {
        console.error('Upload error:', error);
        showError(error.message || 'Failed to process files. Please try again.');
        loading.classList.remove('show');
        uploadButton.disabled = false;
    }
}

function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
}

function renderDashboard(data) {
    console.log('Received data:', data);
    console.log('Expenses table:', data.expenses_table);
    console.log('Optimized expenses table:', data.expenses_optimized_table);

    renderMetrics(data.metrics);
    renderChart1(data.chart1);
    renderChart2(data.chart2);
    renderChart3(data.chart3);
    renderChart4(data.chart4);

    if (data.expenses_table && data.expenses_table.length > 0) {
        renderExpensesTable(data.expenses_table, data.metrics);
    } else {
        console.error('No expenses_table data received');
    }

    if (data.expenses_optimized_table && data.expenses_optimized_table.length > 0) {
        renderOptimizedExpensesTable(data.expenses_optimized_table);
    } else {
        console.error('No expenses_optimized_table data received');
    }

    // Принудительно обновляем размеры графиков после рендера
    setTimeout(() => {
        resizeAllCharts();
    }, 100);
}

function resizeAllCharts() {
    const chartIds = ['chart1', 'chart2', 'chart3', 'chart4'];
    chartIds.forEach(chartId => {
        const chartElement = document.getElementById(chartId);
        if (chartElement) {
            Plotly.Plots.resize(chartElement);
        }
    });
}

function renderMetrics(metrics) {
    const metricsGrid = document.getElementById('metricsGrid');

    metricsGrid.innerHTML = `
        <div class="metric-card metric-green">
            <div class="metric-icon">💰</div>
            <div class="metric-label">Gross Profit (Reality)</div>
            <div class="metric-value">$${formatNumber(metrics.gross_profit)}</div>
            <div class="metric-sublabel">Settled orders</div>
        </div>
        <div class="metric-card metric-orange">
            <div class="metric-icon">📦</div>
            <div class="metric-label">Total Expenses</div>
            <div class="metric-value">$${formatNumber(metrics.total_expenses)}</div>
            <div class="metric-sublabel">${metrics.total_expenses_count} transactions</div>
        </div>
        <div class="metric-card metric-blue">
            <div class="metric-icon">💵</div>
            <div class="metric-label">Net Profit (Reality)</div>
            <div class="metric-value">$${formatNumber(metrics.net_profit)}</div>
            <div class="metric-sublabel">Money in hand</div>
        </div>
        <div class="metric-card metric-purple">
            <div class="metric-icon">🤖</div>
            <div class="metric-label">AI Predicted Net Profit</div>
            <div class="metric-value">$${formatNumber(metrics.ai_predicted)}</div>
            <div class="metric-sublabel">ML Forecast</div>
        </div>
    `;
}

function renderChart1(data) {
    const traces = [
        {
            x: data.dates,
            y: data.potential_profit,
            mode: 'lines',
            name: 'Potential Profit (Optimistic)',
            line: { color: '#00CC96', width: 2 },
            hovertemplate: '<b>Date:</b> %{x}<br><b>Optimistic:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.actual_profit,
            mode: 'lines',
            name: 'Actual Profit (Reality)',
            line: { color: '#636EFA', width: 3 },
            fill: 'tonexty',
            fillcolor: 'rgba(0, 204, 150, 0.15)',
            hovertemplate: '<b>Date:</b> %{x}<br><b>Actual:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.potential_loss,
            mode: 'lines',
            name: 'Potential Loss (Pessimistic)',
            line: { color: '#EF553B', width: 2 },
            fill: 'tonexty',
            fillcolor: 'rgba(239, 85, 59, 0.15)',
            hovertemplate: '<b>Date:</b> %{x}<br><b>Pessimistic:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.predicted,
            mode: 'lines',
            name: 'AI Predicted Revenue',
            line: { color: '#AB63FA', width: 2, dash: 'dash' },
            hovertemplate: '<b>Date:</b> %{x}<br><b>AI Predicted:</b> $%{y:.2f}<extra></extra>'
        }
    ];

    const layout = {
        title: '📊 Amazon Business - Profit Analysis',
        xaxis: { title: 'Date' },
        yaxis: { title: 'Accumulated Profit (USD)', tickprefix: '$' },
        hovermode: 'x unified',
        template: 'plotly_white',
        height: 900,
        autosize: true,
        margin: { l: 80, r: 40, t: 80, b: 80 }
    };

    const config = {
        responsive: true,
        displayModeBar: true,
        displaylogo: false
    };

    Plotly.newPlot('chart1', traces, layout, config);
}

function renderChart2(data) {
    const trace = {
        x: data.dates,
        y: data.cumulative,
        mode: 'lines',
        name: 'Cumulative Expenses',
        line: { color: '#EF553B', width: 3 },
        fill: 'tozeroy',
        fillcolor: 'rgba(239, 85, 59, 0.2)',
        hovertemplate: '<b>Date:</b> %{x}<br><b>Total Expenses:</b> $%{y:.2f}<extra></extra>'
    };

    const layout = {
        title: '💸 Cumulative Business Expenses',
        xaxis: { title: 'Date' },
        yaxis: { title: 'Cumulative Expenses (USD)', tickprefix: '$' },
        hovermode: 'x unified',
        template: 'plotly_white',
        height: 800,
        autosize: true,
        margin: { l: 80, r: 40, t: 80, b: 80 }
    };

    const config = {
        responsive: true,
        displayModeBar: true,
        displaylogo: false
    };

    Plotly.newPlot('chart2', [trace], layout, config);
}

function renderChart3(data) {
    const traces = [
        {
            x: data.dates,
            y: data.optimistic,
            mode: 'lines',
            name: 'Net Profit - Optimistic',
            line: { color: '#00CC96', width: 2 },
            hovertemplate: '<b>Date:</b> %{x}<br><b>Optimistic Net:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.predicted,
            mode: 'lines',
            name: 'Net Profit - AI Predicted',
            line: { color: '#AB63FA', width: 2, dash: 'dash' },
            hovertemplate: '<b>Date:</b> %{x}<br><b>AI Predicted Net:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.reality,
            mode: 'lines',
            name: 'Net Profit - Reality',
            line: { color: '#636EFA', width: 3 },
            fill: 'tonexty',
            fillcolor: 'rgba(0, 204, 150, 0.15)',
            hovertemplate: '<b>Date:</b> %{x}<br><b>Reality Net:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.pessimistic,
            mode: 'lines',
            name: 'Net Profit - Pessimistic',
            line: { color: '#EF553B', width: 2 },
            fill: 'tonexty',
            fillcolor: 'rgba(239, 85, 59, 0.15)',
            hovertemplate: '<b>Date:</b> %{x}<br><b>Pessimistic Net:</b> $%{y:.2f}<extra></extra>'
        }
    ];

    const layout = {
        title: '💰 Net Profit Analysis: Real Money in Hand',
        xaxis: { title: 'Date' },
        yaxis: { title: 'Net Profit (USD)', tickprefix: '$', zeroline: true },
        hovermode: 'x unified',
        template: 'plotly_white',
        height: 900,
        autosize: true,
        margin: { l: 80, r: 40, t: 80, b: 80 }
    };

    const config = {
        responsive: true,
        displayModeBar: true,
        displaylogo: false
    };

    Plotly.newPlot('chart3', traces, layout, config);
}

function renderChart4(data) {
    const traces = [
        {
            x: data.dates,
            y: data.optimistic,
            mode: 'lines',
            name: 'Net Profit - Optimistic (Optimized)',
            line: { color: '#00CC96', width: 2 },
            hovertemplate: '<b>Date:</b> %{x}<br><b>Optimistic Net:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.predicted,
            mode: 'lines',
            name: 'Net Profit - AI Predicted (Optimized)',
            line: { color: '#AB63FA', width: 2, dash: 'dash' },
            hovertemplate: '<b>Date:</b> %{x}<br><b>AI Predicted Net:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.reality,
            mode: 'lines',
            name: 'Net Profit - Reality (Optimized)',
            line: { color: '#636EFA', width: 3 },
            fill: 'tonexty',
            fillcolor: 'rgba(171, 99, 250, 0.15)',
            hovertemplate: '<b>Date:</b> %{x}<br><b>Reality Net:</b> $%{y:.2f}<extra></extra>'
        },
        {
            x: data.dates,
            y: data.pessimistic,
            mode: 'lines',
            name: 'Net Profit - Pessimistic (Optimized)',
            line: { color: '#EF553B', width: 2 },
            fill: 'tonexty',
            fillcolor: 'rgba(239, 85, 59, 0.15)',
            hovertemplate: '<b>Date:</b> %{x}<br><b>Pessimistic Net:</b> $%{y:.2f}<extra></extra>'
        }
    ];

    const layout = {
        title: '🎯 Optimized Cash Flow (Settlement-Aware Expense Timing)',
        xaxis: { title: 'Date' },
        yaxis: { title: 'Net Profit (USD)', tickprefix: '$', zeroline: true },
        hovermode: 'x unified',
        template: 'plotly_white',
        height: 900,
        autosize: true,
        margin: { l: 80, r: 40, t: 80, b: 80 },
        shapes: [{
            type: 'line',
            x0: data.dates[0],
            x1: data.dates[data.dates.length - 1],
            y0: 0,
            y1: 0,
            line: {
                color: 'rgba(0,0,0,0.5)',
                width: 1,
                dash: 'dash'
            }
        }],
        annotations: [{
            text: 'Expenses optimized based on AI Predicted revenue (accounts for Amazon settlement periods)',
            xref: 'paper',
            yref: 'paper',
            x: 0.5,
            y: -0.15,
            xanchor: 'center',
            yanchor: 'top',
            showarrow: false,
            font: {
                size: 11,
                color: '#666'
            }
        }]
    };

    const config = {
        responsive: true,
        displayModeBar: true,
        displaylogo: false
    };

    Plotly.newPlot('chart4', traces, layout, config);
}

function formatNumber(num) {
    return num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function renderExpensesTable(expenses, metrics) {
    const container = document.getElementById('expensesTableContainer');

    let tableHTML = `
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th style="text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
    `;

    expenses.forEach(expense => {
        tableHTML += `
            <tr>
                <td>${expense.date}</td>
                <td><strong>${expense.category}</strong></td>
                <td>${expense.description}</td>
                <td class="amount-cell">$${formatNumber(expense.amount)}</td>
            </tr>
        `;
    });

    const totalExpenses = metrics.total_expenses;
    const avgExpense = totalExpenses / expenses.length;

    tableHTML += `
            </tbody>
        </table>
        <div class="table-summary">
            <div class="summary-item">
                <div class="summary-label">Total Expenses</div>
                <div class="summary-value">$${formatNumber(totalExpenses)}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Total Transactions</div>
                <div class="summary-value">${expenses.length}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Average per Transaction</div>
                <div class="summary-value">$${formatNumber(avgExpense)}</div>
            </div>
        </div>
    `;

    container.innerHTML = tableHTML;
}

function renderOptimizedExpensesTable(expenses) {
    const container = document.getElementById('optimizedExpensesTableContainer');

    let tableHTML = `
        <table>
            <thead>
                <tr>
                    <th>Original Date</th>
                    <th>Optimized Date</th>
                    <th style="text-align: center;">Delay (days)</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th style="text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
    `;

    let delayedCount = 0;
    let totalDelay = 0;

    expenses.forEach(expense => {
        const isDelayed = expense.delayed_days > 0;
        const rowClass = isDelayed ? 'delayed' : '';
        const delayCellClass = isDelayed ? 'delay-cell positive' : 'delay-cell zero';
        const delayText = isDelayed ? `+${expense.delayed_days}` : '0';

        if (isDelayed) {
            delayedCount++;
            totalDelay += expense.delayed_days;
        }

        tableHTML += `
            <tr class="${rowClass}">
                <td>${expense.original_date}</td>
                <td><strong>${expense.date}</strong></td>
                <td class="${delayCellClass}">${delayText}</td>
                <td><strong>${expense.category}</strong></td>
                <td>${expense.description}</td>
                <td class="amount-cell">$${formatNumber(expense.amount)}</td>
            </tr>
        `;
    });

    const avgDelay = delayedCount > 0 ? totalDelay / delayedCount : 0;
    const totalAmount = expenses.reduce((sum, e) => sum + e.amount, 0);
    const delayedPercent = (delayedCount / expenses.length * 100).toFixed(1);

    tableHTML += `
            </tbody>
        </table>
        <div class="table-summary">
            <div class="summary-item">
                <div class="summary-label">Total Expenses</div>
                <div class="summary-value">$${formatNumber(totalAmount)}</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Delayed Transactions</div>
                <div class="summary-value">${delayedCount} (${delayedPercent}%)</div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Average Delay</div>
                <div class="summary-value">${avgDelay.toFixed(1)} days</div>
            </div>
        </div>
    `;

    container.innerHTML = tableHTML;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initDragAndDrop);
