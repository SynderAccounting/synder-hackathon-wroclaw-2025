import pandas as pd

# Читаем CSV файл
df = pd.read_csv('amazon_orders_table.csv', encoding='utf-8-sig')

# Добавляем префикс "amazon_" к каждому Settlement ID
df['Settlement ID'] = 'amazon_' + df['Settlement ID'].astype(str)

# Сохраняем обратно
df.to_csv('amazon_orders_table.csv', index=False, encoding='utf-8-sig')

print("Prefix 'amazon_' successfully added to all Settlement IDs!")
print(f"Processed rows: {len(df)}")
print(f"\nFirst 5 rows:")
print(df[['Settlement ID', 'Order ID']].head())
