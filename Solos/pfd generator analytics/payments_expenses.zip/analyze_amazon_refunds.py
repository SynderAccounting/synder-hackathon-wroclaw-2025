import pandas as pd
import numpy as np

# Загружаем данные
df = pd.read_csv('amazon.csv')

# Фильтруем транзакции
orders = df[df['transaction-type'] == 'Order'].copy()
refunds = df[df['transaction-type'] == 'Refund'].copy()

print(f"📊 Всего заказов: {orders['order-id'].nunique()}")
print(f"📊 Всего возвратов: {refunds['order-id'].nunique()}")
print()

# Группируем возвраты по заказам
refund_orders = refunds.groupby('order-id')

total_loss = 0
refund_details = []

for order_id, refund_group in refund_orders:
    # Получаем все строки для этого возврата
    principal = refund_group[refund_group['amount-description'] == 'Principal']['amount'].sum()
    tax = refund_group[refund_group['amount-description'] == 'Tax']['amount'].sum()
    withheld_tax_return = refund_group[refund_group['amount-description'] == 'MarketplaceFacilitatorTax-Principal']['amount'].sum()
    commission_return = refund_group[refund_group['amount-description'] == 'Commission']['amount'].sum()
    fba_fee_return = refund_group[refund_group['amount-description'] == 'FBAPerUnitFulfillmentFee']['amount'].sum()
    refund_commission = refund_group[refund_group['amount-description'] == 'RefundCommission']['amount'].sum()

    # Расчет реального убытка
    # Principal уже отрицательный (мы возвращаем деньги), инвертируем для ясности
    product_cost = abs(principal)

    # Возвращаемые комиссии (положительные в данных)
    returned_fees = commission_return + fba_fee_return

    # Комиссия за возврат (отрицательная)
    refund_fee = abs(refund_commission)

    # Итоговый убыток = стоимость товара - возвращенные комиссии + комиссия за возврат
    real_loss = product_cost - returned_fees + refund_fee

    total_loss += real_loss

    refund_details.append({
        'Order ID': order_id,
        'Product Cost': product_cost,
        'Returned Commission': returned_fees,
        'Refund Fee': refund_fee,
        'Real Loss': real_loss,
        'SKU': refund_group['sku'].iloc[0] if not refund_group['sku'].isna().all() else 'N/A'
    })

# Создаем DataFrame с деталями
refunds_df = pd.DataFrame(refund_details)
refunds_df = refunds_df.sort_values('Real Loss', ascending=False)

print("=" * 80)
print("💸 ТОП-10 САМЫХ ДОРОГИХ ВОЗВРАТОВ:")
print("=" * 80)
print(refunds_df.head(10).to_string(index=False))
print()

print("=" * 80)
print("📈 СТАТИСТИКА ПО ВОЗВРАТАМ:")
print("=" * 80)
print(f"Общее количество возвратов: {len(refunds_df)}")
print(f"Средний убыток на возврат: ${refunds_df['Real Loss'].mean():.2f}")
print(f"Медианный убыток: ${refunds_df['Real Loss'].median():.2f}")
print(f"Максимальный убыток: ${refunds_df['Real Loss'].max():.2f}")
print(f"ОБЩИЙ УБЫТОК: ${total_loss:.2f}")
print()

# Анализ по SKU
print("=" * 80)
print("📦 УБЫТКИ ПО SKU:")
print("=" * 80)
sku_losses = refunds_df.groupby('SKU').agg({
    'Real Loss': ['sum', 'count', 'mean']
}).round(2)
sku_losses.columns = ['Total Loss', 'Refund Count', 'Avg Loss']
sku_losses = sku_losses.sort_values('Total Loss', ascending=False)
print(sku_losses.head(10))
print()

# Сохраняем детальный отчет
refunds_df.to_csv('refunds_analysis.csv', index=False)
print("✅ Детальный отчет сохранен в refunds_analysis.csv")
