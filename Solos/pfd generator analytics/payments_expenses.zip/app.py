from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import pandas as pd
import numpy as np
from datetime import datetime
import os
import io

app = Flask(__name__, static_folder='.')
CORS(app)

# Временное хранилище данных
uploaded_data = {
    'amazon': None,
    'shopify': None,
    'expenses': None,
    'charts_data': None
}

def process_amazon_csv(file_content):
    """Обрабатывает Amazon CSV и создает таблицу заказов"""
    df = pd.read_csv(io.StringIO(file_content.decode('utf-8')))

    orders = []
    settlements = df[df['transaction-type'].isin(['Order', 'Refund'])].groupby(['settlement-id', 'order-id'])

    for (settlement_id, order_id), group in settlements:
        if pd.isna(order_id):
            continue

        settlement_info = df[df['settlement-id'] == settlement_id].iloc[0]
        deposit_date = settlement_info['deposit-date']
        order_date = group['posted-date'].min()
        trans_type = group['transaction-type'].iloc[0]

        if trans_type == 'Order':
            positive_amounts = group[group['amount'] > 0]['amount'].sum()
            principal = group[group['amount-description'] == 'Principal']['amount'].sum()
            refund_fee = max(abs(principal) * 0.03, 5.0)
            shipping_income = group[group['amount-description'] == 'Shipping']['amount'].sum()
            return_shipping_cost = max(8, min(18, abs(principal) * 0.07))
            potential_loss = -(refund_fee + shipping_income + return_shipping_cost)

            orders.append({
                'Settlement ID': settlement_id,
                'Order ID': order_id,
                'Type': trans_type,
                'Order Date': order_date,
                'Deposit Date': deposit_date,
                'Potential Income': round(positive_amounts, 2),
                'Potential Loss': round(potential_loss, 2),
                'Actual Profit': round(group['amount'].sum(), 2)
            })
        else:
            total_amount = group['amount'].sum()
            orders.append({
                'Settlement ID': settlement_id,
                'Order ID': order_id,
                'Type': trans_type,
                'Order Date': order_date,
                'Deposit Date': deposit_date,
                'Potential Income': 0,
                'Potential Loss': 0,
                'Actual Profit': round(total_amount, 2)
            })

    result_df = pd.DataFrame(orders)
    result_df = result_df.sort_values('Order Date', ascending=False)
    return result_df

def optimize_expenses_timeline(expenses_df, predicted_profit_line, date_range):
    """Оптимизирует время трат чтобы predicted balance (с учетом settlement) был >= 0"""

    # Создаем копию expenses с оптимизированными датами
    expenses_optimized = expenses_df.copy()
    expenses_optimized['original_date'] = expenses_optimized['date']
    expenses_optimized['delayed_days'] = 0

    # Для каждой траты проверяем, можем ли мы ее сделать в эту дату
    for idx, expense in expenses_optimized.iterrows():
        expense_date = expense['date']
        expense_amount = expense['amount']

        # Находим ближайшую дату в date_range
        if expense_date < date_range.min():
            expense_date = date_range.min()
        elif expense_date > date_range.max():
            expense_date = date_range.max()

        # Ищем индекс даты в date_range
        date_idx = date_range.get_loc(expense_date) if expense_date in date_range else 0

        # Проверяем PREDICTED баланс на эту дату (учитывает settlement periods)
        predicted_balance = predicted_profit_line.iloc[date_idx] if date_idx < len(predicted_profit_line) else 0

        # Вычисляем накопительные траты до этой даты
        cumulative_expenses = expenses_optimized[expenses_optimized['date'] <= expense_date]['amount'].sum()
        predicted_net_balance = predicted_balance - cumulative_expenses

        # Если PREDICTED баланс отрицательный, сдвигаем трату на более позднюю дату
        if predicted_net_balance < 0:
            # Ищем ближайшую дату когда predicted баланс будет достаточным
            for future_idx in range(date_idx, len(date_range)):
                future_date = date_range[future_idx]
                future_predicted_balance = predicted_profit_line.iloc[future_idx]
                future_cumulative = expenses_optimized[expenses_optimized['date'] < future_date]['amount'].sum()

                if future_predicted_balance - future_cumulative >= expense_amount:
                    # Нашли подходящую дату
                    expenses_optimized.at[idx, 'date'] = future_date
                    expenses_optimized.at[idx, 'delayed_days'] = (future_date - expense['original_date']).days
                    break

    return expenses_optimized

def generate_chart_data(orders_df, expenses_df):
    """Генерирует данные для всех 4 графиков"""

    # Конвертируем даты
    orders_df['Order Date'] = pd.to_datetime(orders_df['Order Date'], errors='coerce')
    orders_df['Deposit Date'] = pd.to_datetime(orders_df['Deposit Date'], errors='coerce')
    orders_df = orders_df.dropna(subset=['Order Date'])
    orders_df = orders_df.sort_values('Order Date')

    # Удаляем timezone
    if hasattr(orders_df['Order Date'].dtype, 'tz') and orders_df['Order Date'].dt.tz is not None:
        orders_df['Order Date'] = orders_df['Order Date'].dt.tz_localize(None)
    if hasattr(orders_df['Deposit Date'].dtype, 'tz') and orders_df['Deposit Date'].dt.tz is not None:
        orders_df['Deposit Date'] = orders_df['Deposit Date'].dt.tz_localize(None)

    # Находим диапазон дат
    start_date = orders_df['Order Date'].min()
    order_max = orders_df['Order Date'].max()
    if not orders_df['Deposit Date'].isna().all():
        deposit_max = orders_df['Deposit Date'].dropna().max()
        end_date = order_max if order_max > deposit_max else deposit_max
    else:
        end_date = order_max

    date_range = pd.date_range(start=start_date, end=end_date, freq='D')

    # Вычисляем прибыль по дням
    actual_profit_values = []
    potential_profit_values = []
    potential_loss_values = []

    for current_date in date_range:
        actual_profit = orders_df[orders_df['Deposit Date'] <= current_date]['Actual Profit'].sum()
        pending_orders = orders_df[
            (orders_df['Order Date'] <= current_date) &
            ((orders_df['Deposit Date'] > current_date) | (orders_df['Deposit Date'].isna()))
        ]
        pending_income = pending_orders['Potential Income'].sum()
        pending_loss = pending_orders['Potential Loss'].sum()

        actual_profit_values.append(actual_profit)
        potential_profit_values.append(actual_profit + pending_income)
        potential_loss_values.append(actual_profit + pending_loss)

    dates = [d.strftime('%Y-%m-%d') for d in date_range.date]
    actual_profit_line = pd.Series(actual_profit_values, index=date_range)
    potential_profit_line = pd.Series(potential_profit_values, index=date_range)
    potential_loss_line = pd.Series(potential_loss_values, index=date_range)

    # AI Predicted line
    predicted_line = actual_profit_line + (potential_profit_line - actual_profit_line) * 0.6
    predicted_line = predicted_line.rolling(window=7, min_periods=1).mean()

    # Обрабатываем expenses
    expenses_df['date'] = pd.to_datetime(expenses_df['date'])
    expenses_df = expenses_df.sort_values('date')

    # Накопительные затраты
    expenses_series = pd.Series(index=date_range, dtype=float)
    for current_date in date_range:
        expenses_up_to_date = expenses_df[expenses_df['date'] <= current_date]['amount'].sum()
        expenses_series[current_date] = expenses_up_to_date

    # График 1: Gross Profit
    chart1_data = {
        'dates': dates,
        'potential_profit': potential_profit_line.values.tolist(),
        'actual_profit': actual_profit_line.values.tolist(),
        'potential_loss': potential_loss_line.values.tolist(),
        'predicted': predicted_line.values.tolist()
    }

    # График 2: Expenses
    expenses_daily = expenses_df.groupby('date')['amount'].sum().reset_index()
    expenses_daily['cumulative'] = expenses_daily['amount'].cumsum()

    chart2_data = {
        'dates': [d.strftime('%Y-%m-%d') for d in expenses_daily['date']],
        'cumulative': expenses_daily['cumulative'].tolist()
    }

    # График 3: Net Profit
    net_profit_optimistic = potential_profit_line - expenses_series
    net_profit_reality = actual_profit_line - expenses_series
    net_profit_pessimistic = potential_loss_line - expenses_series
    net_profit_predicted = predicted_line - expenses_series

    chart3_data = {
        'dates': dates,
        'optimistic': net_profit_optimistic.values.tolist(),
        'reality': net_profit_reality.values.tolist(),
        'pessimistic': net_profit_pessimistic.values.tolist(),
        'predicted': net_profit_predicted.values.tolist()
    }

    # График 4: Optimized (оптимизируем время трат на основе predicted profit)
    expenses_optimized = optimize_expenses_timeline(expenses_df.copy(), predicted_line, date_range)

    # Создаем Series для оптимизированных трат
    expenses_optimized_series = pd.Series(index=date_range, dtype=float)
    for current_date in date_range:
        expenses_up_to_date = expenses_optimized[expenses_optimized['date'] <= current_date]['amount'].sum()
        expenses_optimized_series[current_date] = expenses_up_to_date

    # Рассчитываем оптимизированный net profit
    optimized_net_profit_optimistic = potential_profit_line - expenses_optimized_series
    optimized_net_profit_predicted = predicted_line - expenses_optimized_series
    optimized_net_profit_reality = actual_profit_line - expenses_optimized_series
    optimized_net_profit_pessimistic = potential_loss_line - expenses_optimized_series

    chart4_data = {
        'dates': dates,
        'optimistic': optimized_net_profit_optimistic.values.tolist(),
        'reality': optimized_net_profit_reality.values.tolist(),
        'pessimistic': optimized_net_profit_pessimistic.values.tolist(),
        'predicted': optimized_net_profit_predicted.values.tolist()
    }

    # Метрики
    metrics = {
        'gross_profit': float(actual_profit_line.iloc[-1]),
        'total_expenses': float(expenses_series.iloc[-1]),
        'net_profit': float(net_profit_reality.iloc[-1]),
        'ai_predicted': float(net_profit_predicted.iloc[-1]),
        'pending_income': float(potential_profit_line.iloc[-1] - actual_profit_line.iloc[-1]),
        'pending_loss': float(potential_loss_line.iloc[-1] - actual_profit_line.iloc[-1]),
        'total_orders': int(len(orders_df)),
        'total_expenses_count': int(len(expenses_df))
    }

    # Подготавливаем данные для таблиц
    expenses_table = expenses_df[['date', 'category', 'description', 'amount']].copy()
    expenses_table['date'] = expenses_table['date'].dt.strftime('%Y-%m-%d')

    expenses_optimized_table = expenses_optimized[['original_date', 'date', 'delayed_days', 'category', 'description', 'amount']].copy()
    expenses_optimized_table['original_date'] = pd.to_datetime(expenses_optimized_table['original_date']).dt.strftime('%Y-%m-%d')
    expenses_optimized_table['date'] = pd.to_datetime(expenses_optimized_table['date']).dt.strftime('%Y-%m-%d')

    return {
        'chart1': chart1_data,
        'chart2': chart2_data,
        'chart3': chart3_data,
        'chart4': chart4_data,
        'metrics': metrics,
        'expenses_table': expenses_table.to_dict('records'),
        'expenses_optimized_table': expenses_optimized_table.to_dict('records')
    }

@app.route('/')
def index():
    """Возвращает главную страницу"""
    return send_from_directory('.', 'dashboard.html')

@app.route('/<path:path>')
def serve_static(path):
    """Обслуживает статические файлы (JS, CSS, и т.д.)"""
    return send_from_directory('.', path)

@app.route('/api/upload', methods=['POST'])
def upload_files():
    """API endpoint для загрузки CSV файлов"""
    try:
        # Проверяем наличие обязательного файла expenses
        if 'expenses' not in request.files:
            return jsonify({'error': 'Expenses file is required'}), 400

        # Проверяем наличие хотя бы одного источника платежей
        has_amazon = 'amazon' in request.files and request.files['amazon'].filename != ''
        has_shopify = 'shopify' in request.files and request.files['shopify'].filename != ''

        if not has_amazon and not has_shopify:
            return jsonify({'error': 'At least one payment source (Amazon or Shopify) is required'}), 400

        expenses_file = request.files['expenses']
        expenses_content = expenses_file.read()

        orders_dataframes = []

        # Обрабатываем Amazon CSV если есть
        amazon_orders_df = None
        if has_amazon:
            amazon_file = request.files['amazon']
            amazon_content = amazon_file.read()
            print("Processing Amazon CSV...")
            amazon_orders_df = process_amazon_csv(amazon_content)
            print(f"Amazon orders processed: {len(amazon_orders_df)} rows")
            orders_dataframes.append(amazon_orders_df)

        # Обрабатываем Shopify CSV если есть
        shopify_orders_df = None
        if has_shopify:
            shopify_file = request.files['shopify']
            shopify_content = shopify_file.read()
            print("Processing Shopify CSV...")
            shopify_orders_df = pd.read_csv(io.StringIO(shopify_content.decode('utf-8')))
            print(f"Shopify orders loaded: {len(shopify_orders_df)} rows")
            orders_dataframes.append(shopify_orders_df)

        # Объединяем данные если есть несколько источников
        if len(orders_dataframes) > 1:
            print("Merging payment sources...")
            orders_df = pd.concat(orders_dataframes, ignore_index=True)
            orders_df = orders_df.sort_values('Order Date', ascending=False)
            print(f"Total orders after merge: {len(orders_df)} rows")
        else:
            orders_df = orders_dataframes[0]
            print(f"Using single payment source: {len(orders_df)} rows")

        print("Processing Expenses CSV...")
        # Обрабатываем Expenses CSV
        expenses_df = pd.read_csv(io.StringIO(expenses_content.decode('utf-8')))
        print(f"Expenses loaded: {len(expenses_df)} rows")
        print(f"Expenses columns: {expenses_df.columns.tolist()}")

        print("Generating chart data...")
        # Генерируем данные для графиков
        charts_data = generate_chart_data(orders_df, expenses_df)

        print(f"Charts data keys: {charts_data.keys()}")
        print(f"Expenses table entries: {len(charts_data.get('expenses_table', []))}")
        print(f"Optimized expenses table entries: {len(charts_data.get('expenses_optimized_table', []))}")

        # Сохраняем в глобальное хранилище
        uploaded_data['amazon'] = amazon_orders_df if has_amazon else None
        uploaded_data['shopify'] = shopify_orders_df if has_shopify else None
        uploaded_data['expenses'] = expenses_df
        uploaded_data['charts_data'] = charts_data

        return jsonify({
            'success': True,
            'data': charts_data
        })

    except Exception as e:
        import traceback
        print(f"Error processing upload: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/data', methods=['GET'])
def get_data():
    """Возвращает текущие данные графиков"""
    if uploaded_data['charts_data'] is None:
        return jsonify({'error': 'No data uploaded yet'}), 404

    return jsonify({
        'success': True,
        'data': uploaded_data['charts_data']
    })

if __name__ == '__main__':
    print("Starting Flask server on http://localhost:5000")
    print("Open http://localhost:5000 in your browser")
    app.run(debug=True, host='0.0.0.0', port=5000)
