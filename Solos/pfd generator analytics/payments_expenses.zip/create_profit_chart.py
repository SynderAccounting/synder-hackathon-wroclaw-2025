import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta

# Читаем таблицу заказов
df = pd.read_csv('amazon_orders_table.csv')

# Конвертируем даты в datetime
df['Order Date'] = pd.to_datetime(df['Order Date'])

# Удаляем строки без даты заказа
df = df.dropna(subset=['Order Date'])

# Сортируем по дате
df = df.sort_values('Order Date')

# Находим диапазон дат
start_date = df['Order Date'].min()
end_date = df['Order Date'].max()

print(f"Period: {start_date.date()} to {end_date.date()}")
print(f"Total orders: {len(df)}")
print(f"Total potential income: ${df['Potential Income'].sum():.2f}")
print(f"Total potential loss: ${df['Potential Loss'].sum():.2f}")
print(f"Total actual profit: ${df['Actual Profit'].sum():.2f}")

# Создаем список всех дней
date_range = pd.date_range(start=start_date, end=end_date, freq='D')

# Группируем прибыль по дням
daily_profit = df.groupby(df['Order Date'].dt.date)['Actual Profit'].sum()

# Создаем Series для всех дней (заполняя нулями дни без заказов)
all_days = pd.Series(index=date_range.date, dtype=float)
all_days = all_days.fillna(0)

# Заполняем реальные данные
for date, profit in daily_profit.items():
    all_days[date] = profit

# Вычисляем накопленную прибыль
cumulative_profit = all_days.cumsum()

# Создаем интерактивный график с Plotly
fig = go.Figure()

# Добавляем линию накопленной прибыли
fig.add_trace(go.Scatter(
    x=cumulative_profit.index,
    y=cumulative_profit.values,
    mode='lines',
    name='Accumulated Profit',
    line=dict(color='#00CC96', width=3),
    fill='tozeroy',
    fillcolor='rgba(0, 204, 150, 0.2)',
    hovertemplate='<b>Date:</b> %{x}<br><b>Profit:</b> $%{y:.2f}<extra></extra>'
))

# Добавляем точки для дней с заказами
order_dates = df.groupby(df['Order Date'].dt.date)['Actual Profit'].sum()
cumulative_at_orders = cumulative_profit[cumulative_profit.index.isin(order_dates.index)]

fig.add_trace(go.Scatter(
    x=cumulative_at_orders.index,
    y=cumulative_at_orders.values,
    mode='markers',
    name='Order Days',
    marker=dict(
        size=8,
        color='#636EFA',
        line=dict(width=2, color='white')
    ),
    hovertemplate='<b>Date:</b> %{x}<br><b>Orders:</b> %{text}<br><b>Cumulative:</b> $%{y:.2f}<extra></extra>',
    text=[f"{len(df[df['Order Date'].dt.date == date])} orders" for date in cumulative_at_orders.index]
))

# Настройка внешнего вида
fig.update_layout(
    title={
        'text': 'Amazon Business - Accumulated Profit Over Time',
        'x': 0.5,
        'xanchor': 'center',
        'font': {'size': 24, 'color': '#2C3E50'}
    },
    xaxis_title='Date',
    yaxis_title='Accumulated Profit (USD)',
    hovermode='x unified',
    template='plotly_white',
    width=1400,
    height=700,
    font=dict(size=12),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    ),
    xaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(128, 128, 128, 0.2)'
    ),
    yaxis=dict(
        showgrid=True,
        gridwidth=1,
        gridcolor='rgba(128, 128, 128, 0.2)',
        tickprefix='$'
    )
)

# Сохраняем в HTML
html_file = 'amazon_profit_chart.html'
fig.write_html(html_file)

print(f"\nChart saved to: {html_file}")
print(f"Open this file in your browser to view the interactive chart")
