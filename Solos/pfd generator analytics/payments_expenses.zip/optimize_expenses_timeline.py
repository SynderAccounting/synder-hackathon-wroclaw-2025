import pandas as pd
from datetime import datetime, timedelta

# Читаем исходные траты
expenses_df = pd.read_csv('expenses.csv')
expenses_df['date'] = pd.to_datetime(expenses_df['date'])
expenses_df = expenses_df.sort_values('date')

# Читаем данные графиков для получения predicted revenue
orders_df = pd.read_csv('amazon_orders_table.csv')
orders_df['Order Date'] = pd.to_datetime(orders_df['Order Date'], errors='coerce')
orders_df['Deposit Date'] = pd.to_datetime(orders_df['Deposit Date'], errors='coerce')
orders_df = orders_df.dropna(subset=['Order Date'])
orders_df = orders_df.sort_values('Order Date')

# Убираем timezone
if hasattr(orders_df['Order Date'].dtype, 'tz') and orders_df['Order Date'].dt.tz is not None:
    orders_df['Order Date'] = orders_df['Order Date'].dt.tz_localize(None)
if hasattr(orders_df['Deposit Date'].dtype, 'tz') and orders_df['Deposit Date'].dt.tz is not None:
    orders_df['Deposit Date'] = orders_df['Deposit Date'].dt.tz_localize(None)

# Создаем predicted revenue timeline
start_date = orders_df['Order Date'].min()
order_max = orders_df['Order Date'].max()
if not orders_df['Deposit Date'].isna().all():
    deposit_max = orders_df['Deposit Date'].dropna().max()
    end_date = order_max if order_max > deposit_max else deposit_max
else:
    end_date = order_max

date_range = pd.date_range(start=start_date, end=end_date, freq='D')

# Рассчитываем predicted revenue для каждой даты
predicted_revenue = {}
for current_date in date_range:
    # Фактическая прибыль
    actual_profit = orders_df[orders_df['Deposit Date'] <= current_date]['Actual Profit'].sum()

    # Pending orders
    pending_orders = orders_df[
        (orders_df['Order Date'] <= current_date) &
        ((orders_df['Deposit Date'] > current_date) | (orders_df['Deposit Date'].isna()))
    ]
    pending_income = pending_orders['Potential Income'].sum()

    # Predicted = Actual + 60% от pending
    predicted = actual_profit + pending_income * 0.6

    # Применяем сглаживание 7 дней
    predicted_revenue[current_date] = predicted

# Сглаживание
predicted_series = pd.Series(predicted_revenue)
predicted_smoothed = predicted_series.rolling(window=7, min_periods=1).mean()

# Теперь оптимизируем траты
optimized_expenses = []
pending_expenses = []  # [(amount, category, description, original_date), ...]
cumulative_expenses = 0

print("Optimizing expenses...")
print(f"Period: {start_date.date()} to {end_date.date()}")
print(f"Total expenses to optimize: {len(expenses_df)}")
print()

for current_date in date_range:
    # Get predicted revenue for this date
    if current_date in predicted_smoothed.index:
        current_predicted = predicted_smoothed[current_date]
    else:
        current_predicted = 0

    current_balance = current_predicted - cumulative_expenses

    # Try to add delayed expenses
    new_pending = []
    for exp_item in pending_expenses:
        exp_amount, exp_cat, exp_desc, orig_date = exp_item
        if current_balance >= exp_amount:
            # Can afford this delayed expense
            optimized_expenses.append({
                'date': current_date,
                'category': exp_cat,
                'description': exp_desc,
                'amount': exp_amount,
                'original_date': orig_date,
                'delayed_days': (current_date - orig_date).days
            })
            cumulative_expenses += exp_amount
            current_balance -= exp_amount
        else:
            # Delay further
            new_pending.append(exp_item)
    pending_expenses = new_pending

    # Try to add new expenses for this date
    daily_expenses = expenses_df[expenses_df['date'] == current_date]
    for _, exp_row in daily_expenses.iterrows():
        exp_amount = exp_row['amount']
        if current_balance >= exp_amount:
            # Can afford this expense
            optimized_expenses.append({
                'date': current_date,
                'category': exp_row['category'],
                'description': exp_row['description'],
                'amount': exp_amount,
                'original_date': current_date,
                'delayed_days': 0
            })
            cumulative_expenses += exp_amount
            current_balance -= exp_amount
        else:
            # Delay it
            pending_expenses.append((
                exp_amount,
                exp_row['category'],
                exp_row['description'],
                current_date
            ))

# Add remaining delayed expenses to the end
for exp_item in pending_expenses:
    exp_amount, exp_cat, exp_desc, orig_date = exp_item
    # Add after last date
    last_date = end_date + timedelta(days=len(optimized_expenses) + 1)
    optimized_expenses.append({
        'date': last_date,
        'category': exp_cat,
        'description': exp_desc,
        'amount': exp_amount,
        'original_date': orig_date,
        'delayed_days': (last_date - orig_date).days
    })

# Create DataFrame
optimized_df = pd.DataFrame(optimized_expenses)

# Statistics
delayed_count = (optimized_df['delayed_days'] > 0).sum()
avg_delay = optimized_df[optimized_df['delayed_days'] > 0]['delayed_days'].mean() if delayed_count > 0 else 0
max_delay = optimized_df['delayed_days'].max()

print("=" * 60)
print("OPTIMIZATION RESULTS:")
print("=" * 60)
print(f"Total expenses: {len(optimized_df)}")
print(f"Delayed expenses: {delayed_count} ({delayed_count/len(optimized_df)*100:.1f}%)")
print(f"Average delay: {avg_delay:.1f} days")
print(f"Maximum delay: {max_delay} days")
print()

if delayed_count > 0:
    print("TOP-10 MOST DELAYED EXPENSES:")
    print("-" * 60)
    top_delayed = optimized_df[optimized_df['delayed_days'] > 0].nlargest(10, 'delayed_days')
    for _, row in top_delayed.iterrows():
        print(f"{row['original_date'].date()} -> {row['date'].date()} "
              f"(+{row['delayed_days']} days): ${row['amount']:.2f} - {row['description'][:40]}")
    print()

# Save optimized expenses with all info
output_file = 'expenses_optimized.csv'
optimized_df.to_csv(output_file, index=False)

print(f"Optimized expenses saved to: {output_file}")
print(f"Balance is now always >= 0")
