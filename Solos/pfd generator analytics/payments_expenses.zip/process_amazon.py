import pandas as pd
from datetime import datetime

# Читаем CSV файл
df = pd.read_csv('amazon.csv')

# Группируем по settlement-id и order-id
orders = []

# Получаем уникальные комбинации settlement + order
settlements = df[df['transaction-type'].isin(['Order', 'Refund'])].groupby(['settlement-id', 'order-id'])

for (settlement_id, order_id), group in settlements:
    if pd.isna(order_id):
        continue

    # Получаем информацию о settlement
    settlement_info = df[df['settlement-id'] == settlement_id].iloc[0]
    deposit_date = settlement_info['deposit-date']

    # Дата заказа - берем самую раннюю posted-date для этого заказа
    order_date = group['posted-date'].min()

    # Определяем тип (Order или Refund)
    trans_type = group['transaction-type'].iloc[0]

    # Для Orders считаем доходы и потенциальные убытки
    if trans_type == 'Order':
        # Потенциальный доход = все положительные суммы
        positive_amounts = group[group['amount'] > 0]['amount'].sum()

        # Рассчитываем потенциальный убыток если будет возврат:
        # 1. Refund fee = 3% от Principal, минимум $5
        principal = group[group['amount-description'] == 'Principal']['amount'].sum()
        refund_fee = max(abs(principal) * 0.03, 5.0)

        # 2. Shipping income loss (если клиент платил за доставку, мы теряем этот доход)
        shipping_income = group[group['amount-description'] == 'Shipping']['amount'].sum()

        # 3. Return Shipping cost (обратная доставка, которую платим мы)
        # Формула: max($8, min($18, Price × 0.07))
        # Даже если доставка была бесплатной для клиента, мы платим за возврат
        return_shipping_cost = max(8, min(18, abs(principal) * 0.07))

        # Potential Loss = -(Refund fee + Shipping income + Return Shipping)
        # Отрицательное, потому что это убыток
        potential_loss = -(refund_fee + shipping_income + return_shipping_cost)

        orders.append({
            'Settlement ID': settlement_id,
            'Order ID': order_id,
            'Type': trans_type,
            'Order Date': order_date,
            'Deposit Date': deposit_date,
            'Potential Income': round(positive_amounts, 2),
            'Potential Loss': round(potential_loss, 2),
            'Actual Profit': round(group['amount'].sum(), 2)
        })
    else:
        # Для Refund считаем фактические потери
        # (они уже произошли, это не потенциальные)
        total_amount = group['amount'].sum()

        orders.append({
            'Settlement ID': settlement_id,
            'Order ID': order_id,
            'Type': trans_type,
            'Order Date': order_date,
            'Deposit Date': deposit_date,
            'Potential Income': 0,  # У возвратов нет потенциального дохода
            'Potential Loss': 0,    # Убыток уже в Actual Profit
            'Actual Profit': round(total_amount, 2)
        })

# Создаем DataFrame
result_df = pd.DataFrame(orders)

# Сортируем по дате заказа
result_df = result_df.sort_values('Order Date', ascending=False)

# Сохраняем в CSV
result_df.to_csv('amazon_orders_table.csv', index=False, encoding='utf-8-sig')

# Также создаем сводку по settlements
settlement_summary = []
for settlement_id in df['settlement-id'].unique():
    settlement_data = df[df['settlement-id'] == settlement_id]
    if settlement_data.empty:
        continue

    first_row = settlement_data.iloc[0]
    total = first_row['total-amount']

    settlement_summary.append({
        'Settlement ID': settlement_id,
        'Period Start': first_row['settlement-start-date'],
        'Period End': first_row['settlement-end-date'],
        'Deposit Date': first_row['deposit-date'],
        'Total Amount': total
    })

summary_df = pd.DataFrame(settlement_summary)
summary_df = summary_df.sort_values('Deposit Date', ascending=False)

# Сохраняем в отдельный CSV файл
summary_df.to_csv('amazon_settlements_summary.csv', index=False, encoding='utf-8-sig')

print(f"Orders table created: {len(result_df)} orders -> amazon_orders_table.csv")
print(f"Settlements summary created: {len(summary_df)} settlements -> amazon_settlements_summary.csv")
